import { all } from "redux-saga/effects";
import { watchGetSingleProduct, watcherGetProduct } from "./watcherSaga";

export function* rootSaga() {
  yield all([watcherGetProduct(), watchGetSingleProduct()]);
}

import { call, put } from "redux-saga/effects";
import { getProductList, getSingleProduct } from "./apiService";
import {
  prSaveProductList,
  saveSingleApiProduct,
} from "../ProductReducerSlice";

export function* handelGetProductList() {
  try {
    const response = yield call(getProductList);
    const { data } = response;
    yield put(prSaveProductList(data));
  } catch (error) {
    console.log(error);
  }
}

export function* handelGetSingleProduct({ payload }) {
  try {
    const response = yield call(getSingleProduct, payload);
    const { data } = response;
    yield put(saveSingleApiProduct(data));
  } catch (error) {
    console.log(error);
  }
}

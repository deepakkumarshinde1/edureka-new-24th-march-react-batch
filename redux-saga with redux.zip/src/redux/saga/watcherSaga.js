import { take, takeLatest } from "redux-saga/effects";
import { handelGetProductList, handelGetSingleProduct } from "./apiHandler";
import { apiGetProduct, apiGetSingleProduct } from "../ProductReducerSlice";

// on which redux action the api must get call
export function* watcherGetProduct() {
  // action_type,handler
  yield takeLatest(apiGetProduct.type, handelGetProductList);
}

export function* watchGetSingleProduct() {
  yield takeLatest(apiGetSingleProduct.type, handelGetSingleProduct);
}

import axios from "axios";
const BASE_URL = "https://fakestoreapi.com/";
export let getProductList = async () => {
  let url = BASE_URL + "products";
  return axios.get(url);
};

export let getSingleProduct = async (id) => {
  let url = BASE_URL + "https://fakestoreapi.com/products/" + Number(id);
  return axios.get(url);
};

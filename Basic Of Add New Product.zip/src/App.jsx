import AddProduct from "./components/AddProduct";

let App = () => {
  return (
    <>
      <AddProduct />
    </>
  );
};
export default App; // one time

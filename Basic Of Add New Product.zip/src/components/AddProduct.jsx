import { useState } from "react";
// we object or array store my reference ==> spread operator = { ... } or  [ ... ]
const AddProduct = () => {
  // store products ==> we need a list i.e array => [{...},{...},{...}]
  let [productList, setProductList] = useState([]); // array will empty
  let initialDetails = {
    title: "",
  };
  let [newProduct, setNewProduct] = useState({ ...initialDetails });

  let inputText = (event) => {
    // let value = event.target.value;
    let value = event.target.value;
    let _newProduct = { ...newProduct }; // re-creating an object or creating a new object from newProduct
    _newProduct["title"] = value;
    // newProduct["title"] = value;
    // object or array ==> there value is store by reference
    // updating a state its value must be immutable like a string , number , boolean
    setNewProduct(_newProduct); // modify my state
  };

  let saveProduct = (event) => {
    // prevent default form submission
    event.preventDefault();
    console.log("submit");
    // method add data in js array
    let _productList = [...productList]; // re-creating list to avoid reference issue
    _productList.push({ ...newProduct }); // adding data

    setProductList(_productList); // modifying product list
    setNewProduct({ ...initialDetails }); // resting new product state (for form input)
  };
  return (
    <>
      <section>
        <h1>Add Product</h1>
        <form onSubmit={saveProduct}>
          <div>
            <label htmlFor="">Name</label>
            <input
              type="text"
              placeholder="Enter Product Name"
              value={newProduct.title}
              onChange={inputText}
            />
          </div>
          <button>Save Product</button>
        </form>
      </section>
      <section>
        <table className="table">
          <thead>
            <tr>
              <th width="15%">Sr No</th>
              <th width="65%">Name</th>
              <th width="20%">Action</th>
            </tr>
          </thead>
          <tbody>
            {productList.map((product, index) => {
              return (
                <tr key={index}>
                  <td>{index + 1}</td>
                  <td>{product.title}</td>
                  <td>
                    <button>Del</button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>
    </>
  );
};

export default AddProduct;

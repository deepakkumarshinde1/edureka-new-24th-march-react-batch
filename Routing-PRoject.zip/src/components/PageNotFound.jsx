const PageNotFound = () => {
  return (
    <>
      <center>
        <h1>404 Page is not found </h1>
      </center>
    </>
  );
};

export default PageNotFound;

import Product from "./components/Product";

let App = () => {
  return (
    <>
      <Product />
    </>
  );
};
export default App; // one time

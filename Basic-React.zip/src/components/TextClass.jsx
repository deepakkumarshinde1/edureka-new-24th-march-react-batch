import React from "react";
import Child from "./Child";

// inheritance of React Component
class TextClass extends React.Component {
  // state = { text: "Hello To CLass components" };

  constructor(props) {
    super(props);
    this.state = { text: "Hello to class component" };
  }
  changeText = () => {
    // this.state.text = "Text Change";
    // console.log(this.state.text);

    // modify state ==> setState
    this.setState({ text: "Text Change" });
  };
  // return html like code
  render() {
    return (
      <>
        <h1>{this.state.text}</h1>
        <button onClick={this.changeText}>Change Text</button>
      </>
    );
  }
}

export default TextClass;

// return JSX code
// JSX code must always have one parent
// elements or <></> as a parent

// on click => change a text data

// event ==> user action click
// click , dbl click, keypress , keyup , mouse over , mouse out,
// drag, drop

// DOM (real_event)        vDOM (synthetic) ==>
// onclick                 onClick
// onkeypress              onKeyPress()

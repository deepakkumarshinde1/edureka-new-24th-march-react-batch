import { useState } from "react";
// React ==> Object to destructure ==> {}
// useState will return  array destructure ==> []
const TextFunction = (props) => {
  // call state hook ==> useState()
  let [text, setText] = useState("Text From FC"); // in return a array it will have only 2 value [value, updateState]
  console.log(text);
  // console.log(props);
  let changeText = () => {
    setText("Text Changes in FC"); // modify state
  };
  return (
    <>
      <h1>{text}</h1>
      <button onClick={changeText}>Change Click</button>
    </>
  );
};

export default TextFunction;

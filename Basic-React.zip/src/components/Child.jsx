import React from "react";
class Child extends React.Component {
  constructor(props) {
    super(props);
    console.log(this.props);
  }
  render() {
    return <></>;
  }
}

export default Child;

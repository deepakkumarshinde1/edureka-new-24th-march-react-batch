// main logic
// component by function => functional component

import TextClass from "./components/TextClass";
import TextFunction from "./components/TextFunction";

let App = () => {
  return (
    <>
      <TextClass number={1} statement="This is a props for class component " />
      <TextFunction
        student={"1"}
        number={1}
        isPresent={true}
        list={[10, 20, 30]}
      />
    </>
  );
};

// export

export default App; // one time

// states
// props
// forms
